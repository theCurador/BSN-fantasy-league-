# fantasy-sports-django
fantasy sports dashboard developed in django
